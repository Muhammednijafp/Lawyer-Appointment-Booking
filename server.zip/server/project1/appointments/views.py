from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.decorators import action
from django.utils import timezone
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

from notifications.models import Notification
from chat.models import ChatRoom
from cases.models import Case, CaseActivityLog
from .models import Appointment
from .serializers import AppointmentSerializer


class AppointmentViewSet(viewsets.ModelViewSet):

    serializer_class = AppointmentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user

        if user.role == "CLIENT":
            return Appointment.objects.filter(client=user)

        if user.role == "LAWYER":
            return Appointment.objects.filter(lawyer=user)

        if user.role == "ADMIN":
            return Appointment.objects.all()

        return Appointment.objects.none()

    def perform_create(self, serializer):
        # ✅ Client is set from the logged-in user, not from request data
        appointment = serializer.save(client=self.request.user)

        # ✅ Notify the lawyer about the new appointment request
        Notification.objects.create(
            user=appointment.lawyer,
            title="New Appointment Request",
            message=f"{appointment.client.username} has requested an appointment.",
            notification_type="APPOINTMENT"
        )

        # ✅ Send real-time notification to the lawyer only
        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f"notifications_user_{appointment.lawyer.id}",
            {
                "type": "send_notification",
                "title": "New Appointment Request",
                "message": f"{appointment.client.username} has requested an appointment.",
                "notification_type": "APPOINTMENT",
            }
        )

    # =============================
    # Lawyer: Approve Appointment
    # =============================
    @action(detail=True, methods=["post"])
    def approve(self, request, pk=None):
        appointment = self.get_object()

        # ✅ Role check
        if request.user.role != "LAWYER":
            return Response(
                {"error": "Only a lawyer can approve appointments."},
                status=status.HTTP_403_FORBIDDEN
            )

        # ✅ Ownership check — lawyer can only approve their own appointments
        if appointment.lawyer != request.user:
            return Response(
                {"error": "You can only approve your own appointments."},
                status=status.HTTP_403_FORBIDDEN
            )

        if appointment.status != "Pending":
            return Response(
                {"error": f"Appointment is already {appointment.status}."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # ✅ Fixed: status update and save are now properly outside the if block
        appointment.status = "Approved"
        appointment.save()

        # ✅ Create case from approved appointment
        case = Case.objects.create(
            title=f"{appointment.category.name} Case",
            description=appointment.description,
            client=appointment.client,
            lawyer=appointment.lawyer,
            category=appointment.category,
            status="Ongoing"
        )

        # ✅ Create chat room for the new case
        ChatRoom.objects.get_or_create(case=case)

        # ✅ Log the activity
        CaseActivityLog.objects.create(
            case=case,
            user=request.user,
            action_type="Case Created",
            description="Case auto-created from approved appointment."
        )

        # ✅ Notify the client
        Notification.objects.create(
            user=appointment.client,
            title="Appointment Approved",
            message="Your appointment has been approved and a case has been created.",
            notification_type="APPOINTMENT"
        )

        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f"notifications_user_{appointment.client.id}",
            {
                "type": "send_notification",
                "title": "Appointment Approved",
                "message": "Your appointment has been approved and a case has been created.",
                "notification_type": "APPOINTMENT",
            }
        )

        return Response({
            "message": "Appointment approved and case created.",
            "case_id": case.id,
        })

    # =============================
    # Lawyer: Reject Appointment
    # =============================
    @action(detail=True, methods=["post"])
    def reject(self, request, pk=None):
        appointment = self.get_object()

        if request.user.role != "LAWYER":
            return Response(
                {"error": "Only a lawyer can reject appointments."},
                status=status.HTTP_403_FORBIDDEN
            )

        if appointment.lawyer != request.user:
            return Response(
                {"error": "You can only reject your own appointments."},
                status=status.HTTP_403_FORBIDDEN
            )

        if appointment.status != "Pending":
            return Response(
                {"error": f"Appointment is already {appointment.status}."},
                status=status.HTTP_400_BAD_REQUEST
            )

        appointment.status = "Rejected"
        appointment.save()

        # ✅ Notify client of rejection
        Notification.objects.create(
            user=appointment.client,
            title="Appointment Rejected",
            message="Your appointment request has been rejected.",
            notification_type="APPOINTMENT"
        )

        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(
            f"notifications_user_{appointment.client.id}",
            {
                "type": "send_notification",
                "title": "Appointment Rejected",
                "message": "Your appointment request has been rejected.",
                "notification_type": "APPOINTMENT",
            }
        )

        return Response({"message": "Appointment rejected."})